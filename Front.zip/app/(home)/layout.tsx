// app/(home)/layout.tsx
'use client'
import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'
import { useState } from 'react'
import Sidebar from '@/components/Layouts/AuthLayout/Sidebar'
import Header from '@/components/Layouts/AuthLayout/Header'
export default async function ProtectedLayout({ children }: { children: React.ReactNode }) {
	// const cookieStore = await cookies()
	// const hasAuth = Boolean(cookieStore.get('Authentication')?.value)
	// if (!hasAuth) redirect('/login')

	const [isCollapsed, setIsCollapsed] = useState(false)
	const [stats, setStats] = useState({
		activeContracts: 0,
		pendingObligations: 0,
		overdueObligations: 0,
		completedThisWeek: 0,
	})

	// useEffect(() => {
	// 	(async () => {
	// 		try { setStats(await getContractStats()) } catch {}
	// 	})()
	// }, [])

	return (
		<div className='flex h-screen bg-gradient-to-bl from-slate-50 via-blue-50 to-indigo-50'>
			<Sidebar isCollapsed={isCollapsed} setIsCollapsed={setIsCollapsed} />
			<div className='flex flex-col flex-1 overflow-hidden'>
				<Header stats={stats} />
				<main className='flex-1 overflow-y-auto p-10'>{children}</main>
			</div>
		</div>
	)
}
