import React from 'react'

interface IPropsPage {}
const Page: React.FC<IPropsPage> = () => {
	return <div className='space-y-8'>Settings page</div>
}

export default Page
