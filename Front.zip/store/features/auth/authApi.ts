// Redux
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'

// Environment
import environment from '@/config'

// Types
import { RootState } from '@/store/store'
import {
	IConfirmEmailData,
	IConfirmEmailResponse,
	ILoginData,
	ILoginResponse,
	ILogoutData,
	ILogoutResponse,
	IRefreshData,
	IRefreshResponse,
	IResendConfirmEmailData,
	IResendConfirmEmailResponse,
	IResetPasswordSendEmailData,
	IResetPasswordSendEmailResponse,
	IResetPasswordUpdatePasswordData,
	IResetPasswordUpdatePasswordResponse,
	ISignUpData,
	ISignUpResponse,
} from '@/store/features/auth/authTypes'

export const authApi = createApi({
	reducerPath: 'authApi',

	baseQuery: fetchBaseQuery({
		baseUrl: `${environment.BASE_URL}/`,
		credentials: 'include',
		prepareHeaders: (headers, { getState }) => {
			const accessToken = (getState() as RootState).auth.accessToken

			if (accessToken) {
				headers.set('Authorization', `Bearer ${accessToken}`)
			}

			headers.set('Content-Type', 'application/json')

			return headers
		},
	}),

	endpoints: (builder) => ({
		signUp: builder.mutation<ISignUpResponse, ISignUpData>({
			query: (credentials) => ({
				url: 'sign-up',
				method: 'POST',
				body: credentials,
			}),
		}),

		login: builder.mutation<ILoginResponse, ILoginData>({
			query: (credentials) => ({
				url: 'sign-in',
				method: 'POST',
				body: credentials,
			}),
		}),

		me: builder.query<any, void>({ query: () => ({ url: 'me', method: 'GET' }) }),

		resetPasswordSendEmail: builder.mutation({
			query: (payload) => ({
				url: 'reset-password',
				method: 'POST',
				body: payload,
			}),
		}),

		verifyResetToken: builder.query<
			{ token: string; email?: string; expired_at?: string; activate_at?: string },
			{ token: string }
		>({
			query: ({ token }) => ({
				url: `reset-password/${encodeURIComponent(token)}/is-expired`,
				method: 'GET',
			}),
		}),

		confirmResetPassword: builder.mutation<
			{ message: string },
			{ email: string; password: string; token: string }
		>({
			query: (body) => ({ url: 'users/password', method: 'PUT', body }),
		}),

		///////////////

		refresh: builder.mutation<IRefreshResponse, IRefreshData>({
			query: (credentials) => ({
				url: 'refresh',
				method: 'POST',
				body: credentials,
			}),
		}),

		logout: builder.mutation<ILogoutResponse, ILogoutData>({
			query: (refreshToken) => ({
				url: 'logout',
				method: 'POST',
				body: { refreshToken },
			}),
		}),

		resetPasswordUpdatePassword: builder.mutation<
			IResetPasswordUpdatePasswordResponse,
			IResetPasswordUpdatePasswordData
		>({
			query: ({ password, confirmPassword, token }) => ({
				url: `reset/${token}`,
				method: 'POST',
				body: { password, confirmPassword },
			}),
		}),
	}),
})

export const {
	useSignUpMutation,
	useLoginMutation,
	useRefreshMutation,
	useLogoutMutation,

	useVerifyResetTokenQuery,
	useConfirmResetPasswordMutation,

	useResetPasswordSendEmailMutation,
	useResetPasswordUpdatePasswordMutation,
} = authApi
